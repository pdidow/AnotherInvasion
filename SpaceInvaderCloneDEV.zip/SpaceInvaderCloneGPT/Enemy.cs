﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Text;
using AnimatedSprite;

namespace SpaceInvaderCloneGPT
{
    class Enemy
    {
        private Vector2 _enemyPosition;
        private Vector2 _enemyVelocity;
        private int _enemyHealth;
        private int _enemyScore;
        private int _enemyWaveNumber;
        private float _enemyBulletYVelocity;
        public  enum _enemyType { redAlien,greenAlien,yellowAlien};
        private _enemyType _enemyAlienType;
        public enum _enemyState { alive, dead };
        private _enemyState _enemysState;
        private Texture2D _enemyTexture;
        private SpriteAnimation _enemySpriteAnimation;
        private int _enemySpriteWidth;
        private int _enemySpriteHeight;
        private Rectangle _enemyCollisionRect;
        private List<EnemyBullet> _enemyBulletList;

        public _enemyState EnemyState
        {
            get { return _enemysState; }
            set { _enemysState = value; }

        }
        // The enemy's current position on the screen
        public Vector2 EnemyPosition
        {
            get { return _enemyPosition; }
            set { _enemyPosition = value; }
        }

        public _enemyType EnemyAlienType
        {
            get { return _enemyAlienType; }
            set { _enemyAlienType = value; }
        }
        // The enemy's current velocity
        public Vector2 EnemyVelocity
        {
            get { return _enemyVelocity; }
            set { _enemyVelocity = value; }
        }

        //Enemys lives remaining
        public int EnemyHealth
        {
            get { return _enemyHealth; }
            set { _enemyHealth = value; }
        }
        // The enemy's current score
        public int EnemyScore
        {
            get { return _enemyScore; }
            set { _enemyScore = value; }
        }
        public SpriteAnimation EnemySpriteAnimation
        {
            get { return _enemySpriteAnimation; }
            set { _enemySpriteAnimation = value; }
        }
        public Rectangle EnemyCollisionRect
        {
            get { return _enemyCollisionRect; }
            set { _enemyCollisionRect = value; }
        }
        public List<EnemyBullet> EnemyBulletList
        {
            get { return _enemyBulletList; }
            set { _enemyBulletList = value; }
        }
        public int EnemyWaveNumber
        {
            get { return _enemyWaveNumber; }
            set { _enemyWaveNumber = value; }
        }


        public Enemy(Vector2 startPosition,Vector2 startVelocity,int spriteWidth,int spriteHeight,_enemyType _enemyAlienType,int enemyWaveNumber)
        {
            _enemyPosition = startPosition;
            _enemyVelocity = startVelocity;
            _enemyWaveNumber = enemyWaveNumber;
            _enemyBulletYVelocity = enemyWaveNumber / 0.25f;
            //Red alien has 3 hp
            //Green Alien has 2 hp
            //Yellow alien has 1hp
            switch (_enemyAlienType)
            {
                case _enemyType.redAlien:
                    _enemyHealth = 3;
                    break;
                case _enemyType.greenAlien://type1
                    _enemyHealth = 2;
                    break;
                case _enemyType.yellowAlien:
                    _enemyHealth = 1;
                    break;

            }
           
            _enemysState = _enemyState.alive;
            _enemySpriteWidth = spriteWidth;
            _enemySpriteHeight = spriteHeight;
            _enemyCollisionRect = new Rectangle((int)_enemyPosition.X, (int)_enemyPosition.Y, spriteWidth, spriteHeight);
            this._enemyAlienType = _enemyAlienType;
            _enemyBulletList = new List<EnemyBullet>();
            //_enemyBullets = new List<EnemyBullet>();


        }

        public void LoadContent(ContentManager Content)
        {
            
            AnimationClass ani = new AnimationClass();
            switch (_enemyAlienType)
            {
                case _enemyType.greenAlien://Type1 GREEN
                    EnemySpriteAnimation = new SpriteAnimation(Content.Load<Texture2D>("Graphics/Invaders/Type1/invaderType1SpriteSheet_32x32_3frames"), 3, 1); //#frames, # animtions *new chef graphics
                    break;
                case _enemyType.redAlien://Type 2 RED
                    EnemySpriteAnimation = new SpriteAnimation(Content.Load<Texture2D>("Graphics/Invaders/Type2/invaderType2SpriteSheet_32x32_3frames"), 3, 1); //#frames, # animtions *new chef graphics
                    break;
                case _enemyType.yellowAlien://Type3 YELLOW
                    EnemySpriteAnimation = new SpriteAnimation(Content.Load<Texture2D>("Graphics/Invaders/Type3/invaderType3SpriteSheet_32x32_3frames"), 3, 1); //#frames, # animtions *new chef graphics
                    break;

            }

            
            EnemySpriteAnimation.FramesPerSecond = 4;
            
            ani.IsLooping = true;
            EnemySpriteAnimation.AddAnimation("Move", 1, 3, ani.Copy());
            

            EnemySpriteAnimation.Animation = "Move";
            EnemySpriteAnimation.Position = _enemyPosition;
            
        }

        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {

            if (_enemySpriteAnimation.Animation != null)
            {
                
                spriteBatch.Begin();
                _enemySpriteAnimation.Draw(spriteBatch, 1f);
                spriteBatch.End();
            }

        }
        public void Fire(ContentManager Content)
        {
            //Create a new EnemyBuller and Return it
            _enemyBulletList.Add(new EnemyBullet(_enemyPosition, new Vector2(0, _enemyBulletYVelocity),Content));
        }
        public void Update(GameTime gameTime,int screenWidth)
        {

            //if (_enemysState == _enemyState.alive)
            //{
            //    if (_enemyPosition.X >= 0)
            //    {
            //        //Move Left across the screen
            //        _enemyPosition = new Vector2(_enemyPosition.X -= 1 * _enemyVelocity.X, _enemyPosition.Y);
            //    }
            //    else
            //    {
            //        //Change X velocity and move the alien down a row.
            //        _enemyVelocity = new Vector2(_enemyVelocity.X * -1, 0);
            //        _enemyPosition = new Vector2(_enemyPosition.X, _enemyPosition.Y + _enemySpriteHeight);
            //        _enemyPosition = new Vector2(_enemyPosition.X -= 1 * _enemyVelocity.X, _enemyPosition.Y);

            //    }

            //    if (_enemyPosition.X <= screenWidth)
            //    {
            //        //Move Left across the screen
            //        _enemyPosition = new Vector2(_enemyPosition.X -= 1 * _enemyVelocity.X, _enemyPosition.Y);
            //    }
            //    else
            //    {
            //        //Change X velocity and move the alien down a row.
            //        _enemyVelocity = new Vector2(_enemyVelocity.X * -1, 0);
            //        _enemyPosition = new Vector2(_enemyPosition.X, _enemyPosition.Y + _enemySpriteHeight);
            //        _enemyPosition = new Vector2(_enemyPosition.X -= 1 * _enemyVelocity.X, _enemyPosition.Y);

            //    }

            //}
            if (_enemysState == _enemyState.alive)
            {
                if (_enemyPosition.X <= screenWidth)
                {
                    //Move Left across the screen
                    _enemyPosition = new Vector2(_enemyPosition.X -= 1 * _enemyVelocity.X, _enemyPosition.Y);
                }
                else
                {
                    //Change X velocity and move the alien down a row.
                    _enemyVelocity = new Vector2(_enemyVelocity.X * -1, 0);
                    _enemyPosition = new Vector2(_enemyPosition.X, _enemyPosition.Y + _enemySpriteHeight);
                    _enemyPosition = new Vector2(_enemyPosition.X -= 1 * _enemyVelocity.X, _enemyPosition.Y);

                }

                if (_enemyPosition.X >= 0)
                {
                    //Move Left across the screen
                    _enemyPosition = new Vector2(_enemyPosition.X -= 1 * _enemyVelocity.X, _enemyPosition.Y);
                }
                else
                {
                    //Change X velocity and move the alien down a row.
                    _enemyVelocity = new Vector2(_enemyVelocity.X * -1, 0);
                    _enemyPosition = new Vector2(_enemyPosition.X, _enemyPosition.Y + _enemySpriteHeight);
                    _enemyPosition = new Vector2(_enemyPosition.X -= 1 * _enemyVelocity.X, _enemyPosition.Y);

                }

            }
            _enemySpriteAnimation.Position = _enemyPosition;
            _enemyCollisionRect = new Rectangle((int)_enemyPosition.X - _enemySpriteWidth / 2, (int)_enemyPosition.Y - _enemySpriteHeight / 2, _enemySpriteWidth, _enemySpriteHeight);
            _enemySpriteAnimation.Update(gameTime);
        }
    }
}

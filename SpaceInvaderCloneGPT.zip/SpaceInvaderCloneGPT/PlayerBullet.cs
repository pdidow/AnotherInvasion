﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceInvaderCloneGPT
{
    public class PlayerBullet
    {
        private Vector2 _bulletPosition;
        private Vector2 _bulletVelocity;
        private Texture2D _bulletTexture;
        private bool _isActive;
        private Rectangle _bulletCollisionRect;
        // The position of the bullet on the screen
        public Vector2 BulletPosition
        {
            get { return _bulletPosition; }
            set { _bulletPosition = BulletPosition; }
        }

        public Vector2 BulletVelocity
        {
            get { return _bulletVelocity; }
            set { _bulletVelocity = BulletVelocity; }
        }

        public Rectangle BulletCollisionRect
        {
            get { return _bulletCollisionRect; }
            set { _bulletCollisionRect = value; }
        }
        // A flag to indicate whether the bullet is active or not
        public bool IsActive
        {
            get { return _isActive; }
            set { _isActive = value; }
        }


        public Texture2D BulletTexture
        {
            get {return  _bulletTexture; }
            set { _bulletTexture = value; }
        }
        // The bullet's constructor
        public PlayerBullet(Vector2 position)
        {
            _bulletPosition = position;
            _bulletVelocity = new Vector2(0, 8f);
            _bulletCollisionRect = new Rectangle((int)_bulletPosition.X, (int)_bulletPosition.Y, 16, 16);
            IsActive = true;
        }

        // Updates the position of the bullet
        public void Update(GameTime gameTime)
        {
            if (_isActive == true)
            {
                _bulletPosition = new Vector2(_bulletPosition.X, _bulletPosition.Y - 1 * _bulletVelocity.Y);
                _bulletCollisionRect = new Rectangle((int)_bulletPosition.X, (int)_bulletPosition.Y, 16, 16);
            } //Position += Direction * Speed;
        }
        public void LoadContent(ContentManager Content)
        {
            _bulletTexture=Content.Load<Texture2D>("Graphics/bullet1");
        }
        // Renders the bullet on the screen
        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(_bulletTexture, BulletPosition, Color.White);
        }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(_bulletTexture, _bulletPosition, Color.White);
            spriteBatch.End();
        }
        public void Fire()
        {
           
        }
    }

}

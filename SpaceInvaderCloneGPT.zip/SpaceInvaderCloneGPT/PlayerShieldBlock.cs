﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceInvaderCloneGPT
{
    class PlayerShieldBlock
    {
        //Create a Texture for each type of shieldBlock
        private Texture2D _shieldBlockTopLeftTexture;
        private Texture2D _shieldBlockTopRightTexture;
        private Texture2D _shieldBlockBottomLeftTexture;
        private Texture2D _shieldBlockBottomRightTexture;
        private Texture2D _shieldBlockTexture;
        private bool _shieldIsActive;

        private Vector2 _shieldBlockPosition;
        private int _shieldBlockHealth;
        private Rectangle _shieldBlockCollisionRect;
        public enum ShieldBlockType { topLeft,topRight,block,bottomLeft,bottomRight};
        private ShieldBlockType _shieldType;
        public Texture2D ShieldBlockTopLeftTexture
        {
            get { return _shieldBlockTopLeftTexture; }
            set { _shieldBlockTopLeftTexture = value; }
        }
        public Texture2D ShieldBlockTopRightTexture
        {
            get { return _shieldBlockTopRightTexture; }
            set { _shieldBlockTopRightTexture = value; }
        }
        public Texture2D ShieldBlockBottomLeftTexture
        {
            get { return _shieldBlockBottomLeftTexture; }
            set { _shieldBlockBottomLeftTexture = value; }
        }
        public Texture2D ShieldBlockBottomRightTexture
        {
            get { return _shieldBlockBottomRightTexture; }
            set { _shieldBlockBottomRightTexture = value; }
        }
        public Texture2D ShieldBlockTexture
        {
            get { return _shieldBlockTexture; }
            set { _shieldBlockTexture = value; }
        }
        public Vector2 ShieldPosition
        {
            get { return _shieldBlockPosition; }
            set { _shieldBlockPosition = value;}
        }
        public int ShieldBlockHealth
        {
            get { return _shieldBlockHealth; }
            set { _shieldBlockHealth = value; }
        }
        public Rectangle ShieldBlockCollisionRect
        {
            get { return _shieldBlockCollisionRect; }
            set { _shieldBlockCollisionRect = value; }
        }
        public ShieldBlockType BlockType
        {
            get { return _shieldType; }
            set { _shieldType = value; }
        }

        public bool ShieldBlockActive
        {
            get { return _shieldIsActive; }
            set { _shieldIsActive = value; }
        }
        public PlayerShieldBlock(Vector2 shieldPosition,ShieldBlockType type)
        {
            _shieldBlockPosition = shieldPosition;
            _shieldBlockHealth = 1;
            _shieldBlockCollisionRect = new Rectangle((int)_shieldBlockPosition.X, (int)_shieldBlockPosition.Y, 8, 8);
            _shieldIsActive = true;
            _shieldType = type;
            
        }
       
        public void LoadContent(ContentManager Content)
        {
           //Load our Textures for each type of shieldBlock
            _shieldBlockTopLeftTexture = Content.Load<Texture2D>("Graphics/Shield/shieldBlockTopLeft_8x8");
            _shieldBlockTopRightTexture = Content.Load<Texture2D>("Graphics/Shield/shieldBlockTopRight_8x8");
            _shieldBlockBottomLeftTexture = Content.Load<Texture2D>("Graphics/Shield/shieldBlockBottomLeft_8x8");
            _shieldBlockBottomRightTexture = Content.Load<Texture2D>("Graphics/Shield/shieldBlockBottomRight_8x8");
            _shieldBlockTexture = Content.Load<Texture2D>("Graphics/Shield/shieldBlock_8x8");
        }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {         
            spriteBatch.Begin();
            switch (_shieldType)
            {
                case ShieldBlockType.block:
                    if (_shieldIsActive == true)
                    {
                        spriteBatch.Draw(_shieldBlockTexture, _shieldBlockPosition, null, Color.White, 0f, Vector2.Zero, 1f, SpriteEffects.None, 1f);
                    }
                    break;
                case ShieldBlockType.topLeft:
                    if (_shieldIsActive == true)
                    {
                        spriteBatch.Draw(_shieldBlockTopLeftTexture, _shieldBlockPosition, null, Color.White, 0f, Vector2.Zero, 1f, SpriteEffects.None, 1f);
                    }
                    break;
                case ShieldBlockType.topRight:
                    if (_shieldIsActive == true)
                    {
                        spriteBatch.Draw(_shieldBlockTopRightTexture, _shieldBlockPosition, null, Color.White, 0f, Vector2.Zero, 1f, SpriteEffects.None, 1f);
                    }
                    break;
                case ShieldBlockType.bottomLeft:
                    if (_shieldIsActive == true)
                    {
                        spriteBatch.Draw(_shieldBlockBottomLeftTexture, _shieldBlockPosition, null, Color.White, 0f, Vector2.Zero, 1f, SpriteEffects.None, 1f);
                    }
                    break;
                case ShieldBlockType.bottomRight:
                    {
                        if (_shieldIsActive == true)
                        {
                            spriteBatch.Draw(_shieldBlockBottomRightTexture, _shieldBlockPosition, null, Color.White, 0f, Vector2.Zero, 1f, SpriteEffects.None, 1f);
                        }
                        break;
                    }

            }
            
            spriteBatch.End();
                     
            
        } 
    }
}

﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceInvaderCloneGPT
{

    class StarWarpEffect
    {
        private int numStars;
        private Vector2 starPosition;
        private List<Vector2> starPositions;
        private Texture2D texture;
        private Color color;
        private float rotation;
        private Vector2 scale;
        private Vector2 origin;
        private Random random;
        private SpriteEffects effect;
        private float layerDepth;

        public List<Vector2> StarPositions
        {
            get { return starPositions; }
            set { starPositions = value; }
        }


        public StarWarpEffect(SpriteBatch spriteBatch, Texture2D texture, Color color, float rotation, Vector2 origin, Vector2 scale, SpriteEffects effects, float layerDepth)
        {


            // Set the number of stars to be displayed
            int numStars = 1000;
            this.texture = texture;
            this.color = color;
            this.rotation = rotation;
            this.origin = origin;
            this.scale = scale;
            random = new Random();
            // Create a list of star positions
            List<Vector2> starPositions = new List<Vector2>();
            for (int i = 0; i < numStars; i++)
            {
                float x = (float)random.NextDouble() * texture.Width;
                float y = (float)random.NextDouble() * texture.Height;
                starPositions.Add(new Vector2(x, y));
            }


        }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            // Draw the stars with a random scale and rotation
            for (int i = 0; i < numStars; i++)
            {
                Random random = new Random();
                float scaleFactor = (float)random.NextDouble();
                float rotationAmount = (float)random.NextDouble() * MathHelper.TwoPi;
                spriteBatch.Draw(texture, starPosition + starPositions[i], null, color, rotation + rotationAmount, origin, scale * scaleFactor, SpriteEffects.None, 1f);
            }
        }
    }
}

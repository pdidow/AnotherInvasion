﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceInvaderCloneGPT
{
    class EnemyBullet
    {
        private Vector2 _enemyBulletPosition;
        private Vector2 _enemyBulletVelocity;
        private Texture2D _enemyBulletTexture;
        private bool _isActive;
        private Rectangle _enemyBulletCollisionRect;
        // The position of the bullet on the screen
        public Vector2 EnemyBulletPosition
        {
            get { return _enemyBulletPosition; }
            set { _enemyBulletPosition = EnemyBulletPosition; }
        }

        public Vector2 BulletVelocity
        {
            get { return _enemyBulletVelocity; }
            set { _enemyBulletVelocity = BulletVelocity; }
        }

        public Rectangle BulletCollisionRect
        {
            get { return _enemyBulletCollisionRect; }
            set { _enemyBulletCollisionRect = value; }
        }
        // A flag to indicate whether the bullet is active or not
        public bool IsActive
        {
            get { return _isActive; }
            set { _isActive = value; }
        }


        public Texture2D EnemyBulletTexture
        {
            get { return _enemyBulletTexture; }
            set { _enemyBulletTexture = value; }
        }

        //Constructor
        public EnemyBullet(Vector2 startposition,Vector2 startVelocity,ContentManager Content)
        {
            _enemyBulletPosition = startposition;
            _enemyBulletVelocity = startVelocity;            
            _enemyBulletCollisionRect = new Rectangle((int)_enemyBulletPosition.X, (int)_enemyBulletPosition.Y, 8, 8);
            IsActive = true;
            LoadContent(Content);
        }
        // Updates the position of the bullet
        public void Update(GameTime gameTime,int screenWidth,int screenHeight)
        {
            if (_isActive == true)
            {
                _enemyBulletPosition = new Vector2(_enemyBulletPosition.X, _enemyBulletPosition.Y + 1 * _enemyBulletVelocity.Y);
                _enemyBulletCollisionRect = new Rectangle((int)_enemyBulletPosition.X, (int)_enemyBulletPosition.Y, 8, 8);
            } 
            //Set inactive if off the screen
            if (_enemyBulletPosition.Y>screenHeight)
            {
                IsActive = false;
            }
           
        }
        public void LoadContent(ContentManager Content)
        {
            _enemyBulletTexture = Content.Load<Texture2D>("Graphics/Invaders/alienBullet");
        }
        // Renders the bullet on the screen
        public void Draw(SpriteBatch spriteBatch)
        {
             spriteBatch.Draw(_enemyBulletTexture, EnemyBulletPosition, Color.White);
        }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(_enemyBulletTexture, _enemyBulletPosition, Color.White);
            spriteBatch.End();
        }
    }
}

﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceInvaderCloneGPT
{
    public class Player
    {


        private Vector2 _playerPosition;
        private Vector2 _playerVelocity;
        private int _playerLives;
        private int _playerScore;
        private Rectangle _playerCollisionRect;
        public enum _playerState { alive,dead};
        public _playerState _playersState;
        private Texture2D _playerTexture;
        private KeyboardState pastKey;
        private GamePadState pastGamePadState;
        private List<PlayerBullet> _playerBullets;
        private int _playerWidth;
        private int _playerHeight;

        private const float PLAYERSCALE = 1f;
        // The player's current position on the screen
        public Vector2 PlayerPosition
        {
            get { return _playerPosition; }
            set { _playerPosition = value; }
        }


        // The player's current velocity
        public Vector2 PlayerVelocity
        {
            get { return _playerVelocity; }
            set { _playerVelocity = value; }
        }

        //Players lives remaining
        public int PlayerLives
        {
            get { return _playerLives; }
            set { _playerLives = value; }
        }
        // The player's current score
        public int PlayerScore
        {
            get { return _playerScore; }
            set { _playerScore = value; }
        }
        public List<PlayerBullet> PlayerBullets
        {
            get { return _playerBullets; }
            set { _playerBullets = value; }
        }
        public Rectangle PlayerCollisionRect
        {
            get { return _playerCollisionRect; }
            set { PlayerCollisionRect = value; }
        }
       public Player(Vector2 startPosition,int maxLives)
        {
            _playerPosition = startPosition;
            _playerVelocity = new Vector2(4f, 0);
            _playerLives = maxLives;
            _playersState = _playerState.alive;
            _playerBullets = new List<PlayerBullet>();
           
        }
        public int PlayerWidth
        {
            get { return _playerWidth; }
            set { _playerWidth = value; }
        }
        public int PlayerHeight
        {
            get { return _playerHeight; }
            set { _playerHeight = value; }
        }
        public _playerState PlayersState
        {
            get { return _playersState; }
            set { _playersState = value; }
        }


        public void LoadContent(ContentManager Content)
        {
            _playerTexture = Content.Load<Texture2D>("Graphics/playerShip32X32");
            _playerWidth = _playerTexture.Width;
            _playerHeight = _playerTexture.Height;
            _playerCollisionRect = new Rectangle((int)_playerPosition.X , (int)_playerPosition.Y - _playerHeight / 2, _playerWidth, _playerHeight);
        }

        public void Draw(GameTime gameTime, SpriteBatch spriteBatch,_playerState state)
        {
            if (state == _playerState.alive)
            {
                spriteBatch.Begin();
                spriteBatch.Draw(_playerTexture, _playerPosition, null, Color.White, 0f, Vector2.Zero, PLAYERSCALE, SpriteEffects.None, 1f);
                spriteBatch.End();
            }
        }
        // Move the player in the direction specified by the velocity
        public void Move(_playerState state)
        {
            if (state == _playerState.alive)
            {
                _playerPosition += _playerVelocity;
                _playerCollisionRect = new Rectangle((int)_playerPosition.X, (int)_playerPosition.Y - _playerHeight / 2, _playerWidth, _playerHeight);
            }
        }

        // Fire the current weapon
        public void Fire(ContentManager Content)
        {
            
                //Create new bullet
                PlayerBullet bullet = new PlayerBullet(new Vector2(_playerPosition.X + _playerWidth / 2 - 4, _playerPosition.Y));//subtract x 4 pixels for the bulletwidth
                bullet.LoadContent(Content);
                _playerBullets.Add(bullet);
            

        }
        public bool GetPlayerInput(int screenWidth, ContentManager Content, _playerState state)
        {
            bool bFiredWeapon = false;
            if (state == _playerState.alive)
            {
                GamePadState gamepadstate = GamePad.GetState(PlayerIndex.One);
                //Check for input
                if (Keyboard.GetState().IsKeyDown(Keys.A) | Keyboard.GetState().IsKeyDown(Keys.Left) ||  gamepadstate.DPad.Left == ButtonState.Pressed  && _playerPosition.X > _playerTexture.Width)
                {
                    _playerPosition = new Vector2(_playerPosition.X - 1 * _playerVelocity.X, _playerPosition.Y);


                }

                if (Keyboard.GetState().IsKeyDown(Keys.D) | Keyboard.GetState().IsKeyDown(Keys.Right) || gamepadstate.DPad.Right == ButtonState.Pressed  && _playerPosition.X < screenWidth)
                {

                    _playerPosition = new Vector2(_playerPosition.X + 1 * _playerVelocity.X, _playerPosition.Y);

                }

                if (Keyboard.GetState().IsKeyDown(Keys.Space) && pastKey.IsKeyUp(Keys.Space)  || gamepadstate.Buttons.A == ButtonState.Pressed && pastGamePadState.Buttons.A == ButtonState.Released)
                {
                    Fire(Content);
                    bFiredWeapon = true;

                }

               
                pastKey = Keyboard.GetState();
                pastGamePadState = GamePad.GetState(PlayerIndex.One);
                _playerCollisionRect = new Rectangle((int)_playerPosition.X, (int)_playerPosition.Y, _playerWidth, _playerHeight);
               
            }
            return bFiredWeapon;
        }
    }

}

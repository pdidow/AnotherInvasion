﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AnimatedSprite;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace AnimatedSprite
{
    struct AnimationPlayer
    {
        AnimatedTexture animation;
        public AnimatedTexture Animation
        {
            get { return animation; }

        }

        int frameIndex;
        public int FrameIndex
        {
            get { return frameIndex; }
            set { frameIndex = value; }
        }

        private float timer;
        public Vector2 Origin
        {
            get { return new Vector2(animation.Width / 2, animation.Height); }
        }
        public void PlayAnimation(AnimatedTexture newAnimation)
        {
            if (animation == newAnimation)

                return;
            animation = newAnimation;
            frameIndex = 0;
            timer = 0;

        }

        public void Draw(GameTime gameTime, SpriteBatch spriteBatch, Vector2 position, SpriteEffects spriteEffects)
        {
            if (Animation == null)
            {
                throw new NotSupportedException("There seems to be no animation selected!sort it out.");
                timer += (float)gameTime.ElapsedGameTime.TotalSeconds;
                while (timer >= animation.FrameTime)
                {
                    timer -= animation.FrameTime;

                    if (animation.IsLooping)
                    {
                        frameIndex = (frameIndex + 1) % animation.FrameCount;
                    }
                    else frameIndex = Math.Min(frameIndex + 1, animation.FrameCount - 1);
                }

                Rectangle rectangle = new Rectangle(frameIndex * Animation.Width, 0, Animation.Width, Animation.Height);
                spriteBatch.Draw(Animation.Texture, position, rectangle, Color.White, 0f, Origin, 1f, spriteEffects, 0);
            }

        }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch, Vector2 position)
        {
            if (Animation == null)
            {
                throw new NotSupportedException("There seems to be no animation selected!sort it out.");
                timer += (float)gameTime.ElapsedGameTime.TotalSeconds;
                while (timer >= animation.FrameTime)
                {
                    timer -= animation.FrameTime;

                    if (animation.IsLooping)
                    {
                        frameIndex = (frameIndex + 1) % animation.FrameCount;
                    }
                    else frameIndex = Math.Min(frameIndex + 1, animation.FrameCount - 1);
                }

                Rectangle rectangle = new Rectangle(frameIndex * Animation.Width, 0, Animation.Width, Animation.Height);
                spriteBatch.Draw(Animation.Texture, position, rectangle, Color.White);
            }
        }
    }
}

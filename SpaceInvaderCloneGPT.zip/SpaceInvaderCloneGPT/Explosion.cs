﻿using AnimatedSprite;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceInvaderCloneGPT
{
    class Explosion
    {
        private Vector2 explosionPosition;
        private SpriteAnimation explosionSpriteAnimation;//Contains our animation sequences
        private float explosionWidth;
        private float explosionHeight;
        private float fExplosionScale;
        private bool bFlaggedForDelete;
        private const int NUMBEROFFRAMES = 5; public bool BFlaggedForDelete
        {
            get { return bFlaggedForDelete; }
            set { bFlaggedForDelete = value; }
        }
        public SpriteAnimation ExplosionSpriteAnimation
        {
            get { return explosionSpriteAnimation; }
            set { explosionSpriteAnimation = value; }
        }


       
        public Explosion(Vector2 position)
        {
            this.explosionPosition = position;
            this.explosionWidth = 32;
            this.explosionHeight = 32;
            this.fExplosionScale = 1f;//not yet utilized.
            this.bFlaggedForDelete = false;

        }
        public void LoadContent(ContentManager Content)
        {
            AnimationClass ani = new AnimationClass();
            explosionSpriteAnimation = new SpriteAnimation(Content.Load<Texture2D>("Graphics/Explosions/ExplosionSheet"), 6, 1); //#frames, # animtions
            explosionSpriteAnimation.FramesPerSecond = 15;

            ani.IsLooping = false;
            explosionSpriteAnimation.AddAnimation("Explode", 1, 6, ani.Copy());
            explosionSpriteAnimation.Animation = "Explode";
            explosionSpriteAnimation.Position = explosionPosition;

        }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {

            if (explosionSpriteAnimation.Animation != null && bFlaggedForDelete == false)
            {
                explosionSpriteAnimation.Draw(spriteBatch, 1f);
            }
            if (explosionSpriteAnimation.FrameIndex >= NUMBEROFFRAMES)
            {
                bFlaggedForDelete = true;
            }





        }
        public void Update(GameTime gameTime)
        {
            explosionSpriteAnimation.Update(gameTime);


        }
    }
}

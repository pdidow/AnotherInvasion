﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using MonoGame.Extended.Tiled;
using MonoGame.Extended.Tiled.Renderers;
using System;
using System.Collections.Generic;

namespace SpaceInvaderCloneGPT
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        private Texture2D _titleScreen;
        private Texture2D _playerTexture;
        private List<Enemy> _enemiesList;
        private List<PlayerShieldBlock> _playerShields;
        private Player _playership;
        private EnemyUFO _enemyUfo;
        private SpriteFont fontTitle;
        private SpriteFont fontScoreboard;
        private Enemy singleTestEnemy;
        private List<Enemy> waveEnemyList;
        private const int SPRITEDIMENSIONS = 32;
        //Load a wave formation
        private TiledMap _tiledMap;        
        private Enemy._enemyType _alienType;
        private SoundEffect _hitAliensound;
        private SoundEffect _fireLaser;
        private SoundEffect _ufoSound;
        private SoundEffect _playerExplodeSound;
        SoundEffectInstance UfoSoundinstance;
        private bool bWaveComplete;
        private int _waveNumber;
        private float _waveCompleteMessageElapsed;//MessageTimer
        private float _waveCompleteMessageTimeLimit;//Timer Limit
        private float _ufoIntervalTimer;//Count x seconds, then send out the ufo
        private float _enemyMovementTimer;//Count x secs/ then move enemy alien
        private float _enemyMovementTimerInterval;//interval for enemy movementupdate
        private float _ufoTimerInterval;//set limit variable
        //Create timer variables for when a random alien will fire Enemybullet
        private float _enemyFireTimer;
        private float _enemyFireTimerInterval;
        //Bullets belong to a wave, so they dont dissapear when we kill an enemy!
        private List<EnemyBullet> _waveEnemyBullets;
        private Explosion playerExplodes;
        private Random randomAlien;
        private ushort[] widths;//screen widths;
        private ushort[] heights;//screen widths;
        private const int MAXNUMBERLEVELS = 5;
        private const int MAXLIVES = 99;
        //Level Warp************************************
        //private StarWarpEffect starFieldLevelWarp;
        //private Texture2D _starWarpTexture;
        //private float _levelWarpTimer;

        //*********************************************************
        //GameStates
        private enum GameState { Title, playing,GameOver};
        private GameState _gamestate;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            _graphics.IsFullScreen = true;
            Content.RootDirectory = "Content";
            IsMouseVisible = false;
            _graphics.PreferredBackBufferWidth = 640;
            _graphics.PreferredBackBufferHeight = 480;
           

            // These arrays contain resolution data. Use the same index on them to get a resolution.
            widths = new ushort[] { 3840, 2560, 2560, 1920, 1366, 1280, 1280 };
            heights = new ushort[] { 2160, 1440, 1080, 1080, 768, 1024, 720 };

        }

        protected override void Initialize()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);
            // TODO: Add your initialization logic here
            _enemiesList = new List<Enemy>();
            //Create Shield List
            _playerShields = new List<PlayerShieldBlock>();
            
            //Initialize Playership
            _playership = new Player(new Vector2(_graphics.PreferredBackBufferWidth/2+32, _graphics.PreferredBackBufferHeight - 32),99);
            _enemyUfo = new EnemyUFO(new Vector2(_graphics.PreferredBackBufferWidth, 16), new Vector2(1f, 0),42,15);
            //singleTestEnemy = new Enemy(new Vector2(_graphics.PreferredBackBufferWidth - 100, 100), new Vector2(1f, 0), 16, 16, Enemy._enemyType.greenAlien);
            waveEnemyList = new List<Enemy>();
            //Bullets now belong to the wave as we dont want them to simply dissappear when we kill an enemy! Dec 19 2022
            _waveEnemyBullets = new List<EnemyBullet>();
            //Initialize Timers
            _waveCompleteMessageElapsed = 0f;
            _waveCompleteMessageTimeLimit = 5f;//five seconds
            _enemyFireTimer = 0f;
            _enemyFireTimerInterval = 1f;//every 1 seconds an alien fires. make more difficult as levels progress
            _enemyMovementTimer=0f;//counter.every 1 seconds an alien moves. make more difficult as levels progress
            _enemyMovementTimerInterval = 0.5f;//the interval for the enemyMovementTImer
            //Ufo frequency
            _ufoTimerInterval = 30;
            //Random Seed
            randomAlien = new Random();
            _gamestate = GameState.Title;
            //Set Initial Wave Number
            _waveNumber = 1;
            _graphics.ApplyChanges();
            base.Initialize();
        }

        protected override void LoadContent()
        {
            //Load a star texture for the starfield warp level thing
            //_starWarpTexture = Content.Load<Texture2D>("Graphics/starFieldobject");
           // _playerTexture = Content.Load<Texture2D>("Graphics/playership16x16");
            _playerTexture = Content.Load<Texture2D>("Graphics/playership32x32");
            //Load the TitleScreen
           
            _titleScreen = Content.Load<Texture2D>("Graphics/TitleScreen");
            //Load Sound Effects
            _hitAliensound = Content.Load<SoundEffect>("SoundEffects/hit1");
            _fireLaser = Content.Load<SoundEffect>("SoundEffects/fireLaser");
            _ufoSound = Content.Load<SoundEffect>("SoundEffects/ufoEffect");
            //Player Explosion Sound Effect
            _playerExplodeSound = Content.Load<SoundEffect>("SoundEffects/Explosions/atari_boom");
            //Ufo Sound
            UfoSoundinstance = _ufoSound.CreateInstance();
            // Set some properties
            UfoSoundinstance.Pitch = 0.0f;//0 is the normal value!
            UfoSoundinstance.Volume = 1.0f;//maxvalue
            //Load Fonts
            fontTitle = Content.Load<SpriteFont>("fonts/HAMMRF");
            fontScoreboard= Content.Load<SpriteFont>("fonts/HAMMRF18");
            //Load first wave
            _tiledMap = Content.Load<TiledMap>("Graphics/Waves/wave1");
           
            //Rebuild list of blocked spaces for this level
            //Get a list of the blocked spaces from the BlockspacessLayer on TiledMap
            int countAliens = _tiledMap.ObjectLayers[0].Objects.Length;
            
            for (int x1 = 0; x1 < countAliens; x1++)
            {
                string type = _tiledMap.ObjectLayers[0].Objects[x1].Type;
                string name = _tiledMap.ObjectLayers[0].Objects[x1].Name;



                switch (type)
                {
                    case "Type1":
                        _alienType = Enemy._enemyType.greenAlien;
                        break;
                    case "Type2":
                        _alienType = Enemy._enemyType.redAlien;
                        break;
                    case "Type3":
                        _alienType = Enemy._enemyType.yellowAlien;
                        break;

                }
                float waveVelocity = .75f * _waveNumber;
                //Create a new Enemy Alien and add to the wave of enemys
                if (type == "Type1" || type == "Type2" | type == "Type3")
                {
                    waveEnemyList.Add(new Enemy(new Vector2(_tiledMap.ObjectLayers[0].Objects[x1].Position.X, _tiledMap.ObjectLayers[0].Objects[x1].Position.Y), new Vector2(waveVelocity, 0), SPRITEDIMENSIONS, SPRITEDIMENSIONS, _alienType,_waveNumber));

                }
                //Create Shields block by block
                if (name == "shieldBlock")
                {
                    PlayerShieldBlock.ShieldBlockType blockType = new PlayerShieldBlock.ShieldBlockType();
                    switch (type)
                    {
                        case "topLeft":
                            blockType = PlayerShieldBlock.ShieldBlockType.topLeft;
                            break;
                        case "topRight":
                            blockType = PlayerShieldBlock.ShieldBlockType.topRight;
                            break;
                        case "bottomLeft":
                            blockType = PlayerShieldBlock.ShieldBlockType.bottomLeft;
                            break;
                        case "bottomRight":
                            blockType = PlayerShieldBlock.ShieldBlockType.bottomRight;
                            break;
                        case "block":
                            blockType = PlayerShieldBlock.ShieldBlockType.block;
                            break;
                    }
                    _playerShields.Add(new PlayerShieldBlock(new Vector2(_tiledMap.ObjectLayers[0].Objects[x1].Position.X, _tiledMap.ObjectLayers[0].Objects[x1].Position.Y), blockType));

                }

                    

                    
                }

            

            foreach (PlayerShieldBlock ps in _playerShields)
            {
                ps.LoadContent(Content);
            }
            //Load grphics for playership
            _playership.LoadContent(Content);
            //Load Ufo sprites
            _enemyUfo.LoadContent(Content);
            
            //Load the test enemy anition sprites
            //singleTestEnemy.LoadContent(Content);
            foreach (Enemy e in waveEnemyList)
            {
                e.LoadContent(Content);
            }
            //Setup Level Warp for later use
            //starFieldLevelWarp = new StarWarpEffect(_spriteBatch, _starWarpTexture, Color.White, 0f, Vector2.Zero,Vector2.Zero, SpriteEffects.None, 1f);

        }
        protected void LoadNextWave(int _waveNum)
        {
            //increase the movement speed of our alien friends by decreasing the interval for movement
            if (_waveNumber > 1 && _waveNumber<MAXNUMBERLEVELS)
            {
                _enemyMovementTimerInterval -= 0.05f;
                _enemyFireTimerInterval -= .05f;
            }
            if (_waveNumber>MAXNUMBERLEVELS)
            {
                _waveNumber = 1;
            }
            _playership.PlayerPosition=new Vector2(_graphics.PreferredBackBufferWidth / 2 + 32, _graphics.PreferredBackBufferHeight - 32);
            //Clear the Shields from completed level
            _playerShields.Clear();
            //Clear the enemy bullets dec 19
            _waveEnemyBullets.Clear();

            _tiledMap = Content.Load<TiledMap>("Graphics/Waves/wave" + _waveNum);
            int countAliens = _tiledMap.ObjectLayers[0].Objects.Length;

            for (int x1 = 0; x1 < countAliens; x1++)
            {
                string type = _tiledMap.ObjectLayers[0].Objects[x1].Type;
                string name = _tiledMap.ObjectLayers[0].Objects[x1].Name;

                switch (type)
                {
                    case "Type1":
                        _alienType = Enemy._enemyType.greenAlien;
                        break;
                    case "Type2":
                        _alienType = Enemy._enemyType.redAlien;
                        break;
                    case "Type3":
                        _alienType = Enemy._enemyType.yellowAlien;
                        break;

                }
                float waveVelocity = .25f * _waveNumber;
                //Create a new Enemy Alien and add to the wave of enemys
                if (type == "Type1" || type == "Type2" | type == "Type3")
                {
                    waveEnemyList.Add(new Enemy(new Vector2(_tiledMap.ObjectLayers[0].Objects[x1].Position.X, _tiledMap.ObjectLayers[0].Objects[x1].Position.Y), new Vector2(waveVelocity, 0), SPRITEDIMENSIONS, SPRITEDIMENSIONS, _alienType,_waveNumber));
                }
               
                //Create Shields block by block
                if (name == "shieldBlock")
                {
                    PlayerShieldBlock.ShieldBlockType blockType = new PlayerShieldBlock.ShieldBlockType();
                    switch (type)
                    {
                        case "topLeft":
                            blockType = PlayerShieldBlock.ShieldBlockType.topLeft;
                            break;
                        case "topRight":
                            blockType = PlayerShieldBlock.ShieldBlockType.topRight;
                            break;
                        case "bottomLeft":
                            blockType = PlayerShieldBlock.ShieldBlockType.bottomLeft;
                            break;
                        case "bottomRight":
                            blockType = PlayerShieldBlock.ShieldBlockType.bottomRight;
                            break;
                        case "block":
                            blockType = PlayerShieldBlock.ShieldBlockType.block;
                            break;
                    }
                    _playerShields.Add(new PlayerShieldBlock(new Vector2(_tiledMap.ObjectLayers[0].Objects[x1].Position.X, _tiledMap.ObjectLayers[0].Objects[x1].Position.Y), blockType));
                    foreach (PlayerShieldBlock sb in _playerShields)
                    {
                        sb.LoadContent(Content);
                    }
                }

            }
            foreach (Enemy e in waveEnemyList)
            {
                e.LoadContent(Content);
            }
        }
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();
            //Check if any of the aliens have reached the bottom of the screen. If so game over.
            foreach (Enemy e in waveEnemyList)
            {
                if (e.EnemyPosition.Y>=_graphics.PreferredBackBufferHeight-e.EnemySpriteHeight)
                {
                    _gamestate = GameState.GameOver;
                }
            }
            if (_gamestate == GameState.playing)
            {
                if (_playership.GetPlayerInput(_graphics.PreferredBackBufferWidth, Content,_playership.PlayersState) == true)
                {
                    _fireLaser.Play();


                }
            }
            else if (_gamestate == GameState.Title || _gamestate == GameState.GameOver)
            {
                if (Keyboard.GetState().IsKeyDown(Keys.Space) | Keyboard.GetState().IsKeyDown(Keys.Space))
                {
                    //Reset as to a new game

                    _gamestate = GameState.playing;
                    _waveNumber = 1;
                    _playership.PlayerLives = MAXLIVES;
                    _playership.PlayerScore = 0;
                    _enemyMovementTimerInterval = 0.5f;
                    _enemyFireTimerInterval =1f;
                    _playership.PlayerPosition = new Vector2(_graphics.PreferredBackBufferWidth / 2 + 32, _graphics.PreferredBackBufferHeight - 32);
                    _enemyUfo.UFOState = EnemyUFO._ufoState.dead;
                    waveEnemyList.Clear();
                    _waveEnemyBullets.Clear();
                    LoadNextWave(_waveNumber);
                }
            }
                //Update Player Bullet Position
                foreach (PlayerBullet pb in _playership.PlayerBullets)
            {
                pb.Update(gameTime);
            }


            //Check Collision
            //Check for BulletCollisions
            CheckBulletCollisions();
           
            //Clean up the Inactive player bullets.
            var foundInactive = _playership.PlayerBullets.Find(x => x.IsActive == false);
            if (foundInactive != null)
            {
                _playership.PlayerBullets.Remove(foundInactive);
            }
            //Clean up the Inactive Alien bullets
            // Removed as the enemy no longer has a list of bullets. this was moved to the game class as _waveEnemyBullets
            // as the bullets would dissapear when an enemy was removed

            //foreach (Enemy e in waveEnemyList)
            //{
            //    var foundInactiveAlienBullets = e.EnemyBulletList.Find(x => x.IsActive == false);
            //    if (foundInactiveAlienBullets != null)
            //    {
            //        e.EnemyBulletList.Remove(foundInactiveAlienBullets);
            //    }

            //}


           
            //Clean up the inactive shieldBlocks          
            var foundBlockInactive = _playerShields.Find(x => x.ShieldBlockActive == false);
            if (foundBlockInactive!=null)
            {
                _playerShields.Remove(foundBlockInactive);
            }


            //Find the dead aliens and then remove them from the wave.
            var foundDead = waveEnemyList.Find(x => x.EnemyState == Enemy._enemyState.dead);
            if (foundDead!=null)
            {
                //explode alien
                //todo
                //play hit sound for the dead alien
                _hitAliensound.Play();
                //remove the dead alien
                waveEnemyList.Remove(foundDead);
                //Increase the velocity of the remaining aliens
                foreach (Enemy e in waveEnemyList)
                {
                   // e.EnemyVelocity = new Vector2(e.EnemyVelocity.X + .05f*_waveNumber, e.EnemyVelocity.Y);
                }
            }
          
            

            //Find if the UFO is dead, remove if so.
            if (_enemyUfo.UFOState==EnemyUFO._ufoState.dead)
            {
               //explode ufo
            }
            //if the game is not over, we update the enemy
            switch (_gamestate)
            {
                case GameState.playing:
                    _enemyMovementTimer += (float)gameTime.ElapsedGameTime.TotalSeconds;
                    if (_enemyMovementTimer >= _enemyMovementTimerInterval)
                    {
                        foreach (Enemy e in waveEnemyList)
                        {
                            e.Update(gameTime, _graphics.PreferredBackBufferWidth);
                        }

                        _enemyMovementTimer = 0f;
                    }
                    else
                    {
                        foreach (Enemy e in waveEnemyList)
                        {
                            e.UpdateAnimation(gameTime);
                        }
                    }
                    break;
                case GameState.GameOver:
                    //Update the animation but font move the aliens
                    foreach (Enemy e in waveEnemyList)
                    {
                        e.UpdateAnimation(gameTime);
                    }
                    break;
            }
           
            foreach (EnemyBullet eb in _waveEnemyBullets)
            {
                if (eb.BulletCollisionRect.Intersects(_playership.PlayerCollisionRect))
                {
                    //Set the enemy bullet inactive and then subtract one of the players lives
                    eb.IsActive = false;
                    _playership.PlayerLives -= 1;
                    //Create an Explosion
                    playerExplodes = new Explosion(new Vector2(_playership.PlayerPosition.X+_playership.PlayerWidth/2,_playership.PlayerPosition.Y+_playership.PlayerHeight/2));
                    _playerExplodeSound.CreateInstance().Play();
                    playerExplodes.LoadContent(Content);
                    if (_playership.PlayersState==Player._playerState.alive)
                    {
                        _playership.PlayersState = Player._playerState.dead;
                        _playership.PlayerPosition = new Vector2(_graphics.PreferredBackBufferWidth / 2 + 32, _graphics.PreferredBackBufferHeight - 32);
                    }

                    if (_playership.PlayerLives <= 0)
                    {
                        _gamestate = GameState.GameOver;
                        ClearSheilds();
                    }
                }



                eb.Update(gameTime, _graphics.PreferredBackBufferWidth, _graphics.PreferredBackBufferHeight);

            }
            //Update the Ufo
            _enemyUfo.Update(gameTime);
            if (waveEnemyList.Count < 1)
            {
                //Wave complete.
                bWaveComplete = true;
               
            }
            if (bWaveComplete==true)
            {
                _waveCompleteMessageElapsed += (float)gameTime.ElapsedGameTime.TotalSeconds;
                if (_waveCompleteMessageElapsed >= _waveCompleteMessageTimeLimit)
                {
                    bWaveComplete = false;
                    _waveCompleteMessageElapsed = 0;//reset timer to zero. test.
                    _waveNumber += 1;
                    //load level
                    LoadNextWave(_waveNumber);

                }
            }
            _ufoIntervalTimer += (float)gameTime.ElapsedGameTime.TotalSeconds;
            if (_ufoIntervalTimer>=_ufoTimerInterval && _enemyUfo.UFOState==EnemyUFO._ufoState.dead)
            {
                //reset ufo.
                _enemyUfo.UFOState = EnemyUFO._ufoState.alive;
                _enemyUfo.UfoPosition = new Vector2(_graphics.PreferredBackBufferWidth, 16);
                _enemyUfo.UfoVelocity = new Vector2(1f, 0);
                _ufoIntervalTimer = 0;
               
            }
           
                
           if (_enemyUfo.UFOState==EnemyUFO._ufoState.alive)
            {
                // Play the Ufo sound effect looping.
                UfoSoundinstance.Play();
               
            }
           else
            {
                UfoSoundinstance.Stop();
            }
            _enemyFireTimer += (float)gameTime.ElapsedGameTime.TotalSeconds;
            if (_enemyFireTimer>=_enemyFireTimerInterval)
            {
                //whenever this timer fires, we select a random alien to fire upon the player.
                int randomMax = waveEnemyList.Count;
                int randINT=randomAlien.Next(randomMax);
                if (waveEnemyList.Count>0 && _gamestate==GameState.playing)
                {
                    //waveEnemyList[randINT].Fire(Content);
                    //Changed this as we need to add bullets to the waveEnemyBullets, not the enemies's bullet list- as this resulted in dissappearing bullets when enemy killed!
                    _waveEnemyBullets.Add(waveEnemyList[randINT].GetNewBullet(Content));//dec19 2022
                }
                //reset timer.
                _enemyFireTimer = 0;
            }
            //Clean up the inactive alien bullets
            var itemToRemove = _waveEnemyBullets.Find(x => x.IsActive == false);
            _waveEnemyBullets.Remove(itemToRemove);
            if (playerExplodes!=null)
            {
                playerExplodes.Update(gameTime);
                if (playerExplodes.ExplosionSpriteAnimation.FrameIndex >= 5)
                {
                    playerExplodes = null;
                    _playership.PlayersState = Player._playerState.alive;
                }

            }
            
            base.Update(gameTime);
        }
        public void CheckBulletCollisions()
        {
            //Check for collision with the shields
            foreach (PlayerShieldBlock shld in _playerShields)
            {
                //check the player bullets
                foreach (PlayerBullet pb in _playership.PlayerBullets)
                {

                    //Check if we hit our own shields
                    if (pb.BulletCollisionRect.Intersects(shld.ShieldBlockCollisionRect) && pb.IsActive==true)
                      {
                        //reduce health of the shield                     
                        shld.ShieldBlockHealth -= 1;//lose 1 pt shield health
                        //Deactivate bullet for hitting shield
                        pb.IsActive = false;
                        if (shld.ShieldBlockHealth<=0)
                        {
                            //set block inactive for removal on cleanup 
                            shld.ShieldBlockActive = false;
                        }


                    }
                }
            //Check the aliens bullets for collision with the shieldBlocks
          
                foreach(EnemyBullet eb in _waveEnemyBullets)
                {
                    if (eb.BulletCollisionRect.Intersects(shld.ShieldBlockCollisionRect) && eb.IsActive == true)
                    {
                        //reduce health of the shield                     
                        shld.ShieldBlockHealth -= 1;//lose 1 pt shield health
                        //Deactivate bullet for hitting shield
                        eb.IsActive = false;
                        if (shld.ShieldBlockHealth <= 0)
                        {
                            //set block inactive for removal on cleanup 
                            shld.ShieldBlockActive = false;
                        }

                    }
                }


                //}
            }
            
            foreach (PlayerBullet pb in _playership.PlayerBullets)
            {
                //Check for collision with EnemyUFO
                if (pb.BulletCollisionRect.Intersects(_enemyUfo.UfoCollisionRect))
                 {
                    //Bullet hit the Ufo. explode and remove.
                    //add to the playerscore.
                    _playership.PlayerScore += 100;
                    //deactivate the bullet
                    pb.IsActive = false;
                    //Set the UFO state to dead[todo: until timer sets it active again
                    _enemyUfo.UFOState = EnemyUFO._ufoState.dead;
                }
                //Check for collision with Aliens!
                foreach (Enemy alien in waveEnemyList)
                {
                    if (pb.BulletCollisionRect.Intersects(alien.EnemyCollisionRect))
                    {
                        //Bullet hit the Alien. Subtract from health.
                        alien.EnemyHealth -= 1;
                        //deactivate the bullet
                        pb.IsActive = false;
                    }
                    //Health of the alien is now zero. then flag them as dead to be removed from list
                    if (alien.EnemyHealth<=0 && alien.EnemyState==Enemy._enemyState.alive)
                    {
                        alien.EnemyState = Enemy._enemyState.dead;
                        //add to the playerscore.
                        switch (alien.EnemyAlienType)
                        {
                            case Enemy._enemyType.redAlien:
                                _playership.PlayerScore += 100;
                                break;
                            case Enemy._enemyType.greenAlien:
                                 _playership.PlayerScore += 50;
                                break;
                            case Enemy._enemyType.yellowAlien:
                                _playership.PlayerScore += 30;
                                break;

                        }
                        
                    }

                }
            }
        }
        protected override void Draw(GameTime gameTime)
        {
          
            GraphicsDevice.Clear(Color.Black);
            
            //Draw Player Shields
            foreach (PlayerShieldBlock ps in _playerShields)
            {
                ps.Draw(gameTime, _spriteBatch);
            }

            //debug Shield rect
            //Texture2D _texture;
            //_texture = new Texture2D(_graphics.GraphicsDevice, 1, 1);
            //_texture.SetData(new Color[] { Color.Red });
            //foreach (PlayerShieldBlock ps in _playerShields)
            //{
            //    _spriteBatch.Begin(SpriteSortMode.FrontToBack, BlendState.AlphaBlend, null, null, null, null, null);
            //    _spriteBatch.Draw(_texture, ps.ShieldBlockCollisionRect, Color.White);
            //    _spriteBatch.End();
            //}
            //Draw the Player
            
            _playership.Draw(gameTime, _spriteBatch,_playership.PlayersState);
           
          
           
            
            //Draw the Bullets
            foreach (PlayerBullet pb in _playership.PlayerBullets)
            {
                pb.Draw(gameTime, _spriteBatch);
            }
            //Draw the Ufo if alive.
            if (_enemyUfo.UFOState == EnemyUFO._ufoState.alive)
            {
                _enemyUfo.Draw(gameTime, _spriteBatch);
            }
            //Draw the Aliens
            foreach (Enemy e in waveEnemyList)
            {
                e.Draw(gameTime, _spriteBatch);
                //remove dec 19 2020 as  we need to add bullets to the waveEnemyBullets, not the enemies's bullet list- as this resulted in dissappearing bullets when enemy killed!
                //foreach (EnemyBullet eb in e.EnemyBulletList)
                //{
                //    if (eb.IsActive == true)
                //    {
                //        eb.Draw(gameTime, _spriteBatch);
                //    }
                //}
            }
            //Draw the enemy bullets dec 19 2020 as  we need to add bullets to the waveEnemyBullets, not the enemies's bullet list- as this resulted in dissappearing bullets when enemy killed!
            foreach (EnemyBullet eb in _waveEnemyBullets)
            {
                if (eb.IsActive == true)
                {
                    eb.Draw(gameTime, _spriteBatch);
                }
            }
            //Draw the player explosion if exists
            if (playerExplodes!=null)
            {
                _spriteBatch.Begin(SpriteSortMode.FrontToBack, BlendState.AlphaBlend, null, null, null, null, null);
                playerExplodes.Draw(gameTime, _spriteBatch);               
                _spriteBatch.End();
            }
            if (_gamestate == GameState.playing)
            {
                int indent = 32;
                //Draw the score
                _spriteBatch.Begin(SpriteSortMode.FrontToBack, BlendState.AlphaBlend, null, null, null, null, null);
                _spriteBatch.DrawString(fontScoreboard, _playership.PlayerScore.ToString(), new Vector2(_graphics.PreferredBackBufferWidth - _playership.PlayerScore.ToString().Length+indent, 32), Color.White);
                //_spriteBatch.DrawString(font, "x"+_playership.PlayerLives, new Vector2(_graphics.PreferredBackBufferWidth - _playership.PlayerLives.ToString().Length, 68), Color.White);
                //Draw the player ships remaining
                _spriteBatch.Draw(_playerTexture, new Vector2(_graphics.PreferredBackBufferWidth+ _playerTexture.Width/2-25+indent, _graphics.PreferredBackBufferWidth/4 ), Color.White);
                _spriteBatch.DrawString(fontScoreboard, "x" + _playership.PlayerLives, new Vector2(_graphics.PreferredBackBufferWidth +_playership.PlayerWidth*2, _graphics.PreferredBackBufferWidth / 4), Color.White);

                _spriteBatch.End();
                //Draw the Wave Number
                _spriteBatch.Begin(SpriteSortMode.FrontToBack, BlendState.AlphaBlend, null, null, null, null, null);
                string wavestring = "Wave:" + _waveNumber;
                _spriteBatch.DrawString(fontScoreboard, "Wave: " + _waveNumber, new Vector2(_graphics.PreferredBackBufferWidth - wavestring.Length+indent, 102), Color.White);
                _spriteBatch.End();
            }
            if (_gamestate==GameState.GameOver)
            {
                _spriteBatch.Begin(SpriteSortMode.FrontToBack, BlendState.AlphaBlend, null, null, null, null, null);
                _spriteBatch.DrawString(fontScoreboard, "Game Over", new Vector2(_graphics.PreferredBackBufferWidth / 2 - 100, _graphics.PreferredBackBufferHeight/2), Color.Red);
                _spriteBatch.DrawString(fontScoreboard, "press space to begin", new Vector2(_graphics.PreferredBackBufferWidth / 2 - 170, _graphics.PreferredBackBufferWidth/2-34), Color.White);
                _spriteBatch.End();
            }
            //Title Screen
            if (_gamestate==GameState.Title)
            {
                //Draw the titleScreen
                _spriteBatch.Begin(SpriteSortMode.FrontToBack, BlendState.AlphaBlend, null, null, null, null, null);
                _spriteBatch.Draw(_titleScreen, new Vector2(0, 0), Color.White);
                _spriteBatch.DrawString(fontTitle, "Press Fire to Start", new Vector2(_graphics.PreferredBackBufferWidth/2-175,175), Color.White);
               
                _spriteBatch.End();

            }
            //Wave Complete. Display for the time limit specified by _waveCompleteMessageTimeLimit
            if (bWaveComplete==true && _waveCompleteMessageElapsed<=_waveCompleteMessageTimeLimit)
            {
                _spriteBatch.Begin(SpriteSortMode.FrontToBack, BlendState.AlphaBlend, null, null, null, null, null);
                _spriteBatch.DrawString(fontTitle, "Wave Complete!", new Vector2(_graphics.PreferredBackBufferWidth/4 - "Wave Complete!".Length, 32), Color.White);
    
                _spriteBatch.End();
            }
            
            base.Draw(gameTime);
        }


        void ChangeResolution(byte newResolution)
        {
            // Only change resolution if the newResolution is between 0 and the length of the widths array
            if (newResolution >= 0 && newResolution < widths.Length)
            {
                // Change the width and height to the new values in the array
                _graphics.PreferredBackBufferWidth = widths[newResolution];
                _graphics.PreferredBackBufferHeight = heights[newResolution];
                // Apply the changes
                _graphics.ApplyChanges();
                //System.Console.WriteLine("New resolution: {0} x {1}", _graphics.PreferredBackBufferWidth, _graphics.PreferredBackBufferHeight);
            }
        }


        public void ClearSheilds()
        {
            //Clear the Shields from completed level
            _playerShields.Clear();
           
        }
    }
}

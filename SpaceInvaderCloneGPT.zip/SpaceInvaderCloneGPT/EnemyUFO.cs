﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Text;
using AnimatedSprite;

namespace SpaceInvaderCloneGPT
{
    class EnemyUFO
    {
        private Vector2 _ufoPosition;
        private Vector2 _ufoStartPosition;
        private Vector2 _ufoVelocity;
        private Rectangle _ufoCollisionRect;
        private int _ufoSpriteWidth;
        private int _ufoSpriteHeight;

        private SpriteAnimation _ufoSpriteAnimation;
       public enum _ufoState { alive, dead };
        private _ufoState _ufosState;

        public Vector2 UfoPosition
        {
            get { return _ufoPosition; }
            set { _ufoPosition = value; }
        }

        public _ufoState UFOState
        {
            get { return _ufosState; }
            set { _ufosState = value; }
        }


        // The ufo's current velocity
        public Vector2 UfoVelocity
        {
            get { return _ufoVelocity; }
            set { _ufoVelocity = value; }
        }
        public SpriteAnimation UfoSpriteAnimation
        {
            get { return _ufoSpriteAnimation; }
            set { _ufoSpriteAnimation = value; }
        }
        public Vector2 UfoStartPosition
        {
            get { return _ufoStartPosition; }
            set { _ufoStartPosition = value; }
        }
        public Rectangle UfoCollisionRect
        {
            get { return _ufoCollisionRect; }
            set { _ufoCollisionRect = value; }
        }
        public int UfoSpriteWidth
        {
            get { return _ufoSpriteWidth; }
            set { _ufoSpriteWidth = value; }
        }
        public int UfoSpriteHeight
        {
            get { return _ufoSpriteHeight; }
            set { _ufoSpriteHeight = value; }
        }


        public EnemyUFO(Vector2 startPosition, Vector2 startVelocity,int spriteWidth,int spriteHeight)
        {
            _ufoPosition = startPosition;
            _ufoStartPosition = startPosition;
            _ufoVelocity = startVelocity;
            _ufoCollisionRect = new Rectangle((int)_ufoPosition.X, (int)_ufoPosition.Y, spriteWidth, spriteHeight);
            _ufosState = _ufoState.dead;
            _ufoSpriteWidth = spriteWidth;
            _ufoSpriteHeight = spriteHeight;
        }
        public void LoadContent(ContentManager Content)
        {
            AnimationClass ani = new AnimationClass();
            _ufoSpriteAnimation = new SpriteAnimation(Content.Load<Texture2D>("Graphics/Invaders/Ufo/ufoSpriteSheet_42x15_6frames"), 6, 1); //#frames, # animtions *new chef graphics
            _ufoSpriteAnimation.FramesPerSecond = 16;

            ani.IsLooping = true;
            _ufoSpriteAnimation.AddAnimation("Rotate", 1, 6, ani.Copy(2f));
            _ufoSpriteAnimation.Animation = "Rotate";
            _ufoSpriteAnimation.Position = _ufoPosition;
        }
        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {

            if (_ufoSpriteAnimation.Animation != null)
            {
                if (_ufosState == _ufoState.alive)
                {
                    spriteBatch.Begin();
                    _ufoSpriteAnimation.Draw(spriteBatch, 1f);
                    spriteBatch.End();
                }
            }

        }
        public void Update(GameTime gameTime)
        {
            if (_ufoPosition.X == 0 && _ufosState==_ufoState.alive)
            {
                _ufoPosition = _ufoStartPosition;
            }

            if (_ufosState==_ufoState.alive && _ufoPosition.X>0)
            {
                //Move Left across the screen
                _ufoPosition = new Vector2(_ufoPosition.X -= 1 * _ufoVelocity.X, UfoPosition.Y);
                _ufoSpriteAnimation.Position = _ufoPosition;
            }
            _ufoCollisionRect = new Rectangle((int)_ufoPosition.X - _ufoSpriteWidth / 2, (int)_ufoPosition.Y - _ufoSpriteHeight / 2, _ufoSpriteWidth,_ufoSpriteHeight);
            _ufoSpriteAnimation.Update(gameTime);
        }
    }
}

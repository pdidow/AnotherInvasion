<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.0" name="Shieldspritesheet_8x8_4Tiles" tilewidth="8" tileheight="8" tilecount="5" columns="5">
 <image source="../Shield/Shieldspritesheet_8x8_4Tiles.png" width="40" height="8"/>
</tileset>
